title: Docker的使用
date: '2019-06-29 11:28:55'
updated: '2019-06-29 11:28:55'
tags: [建站]
permalink: /articles/2019/06/29/1561778935539.html
---
![](https://img.hacpai.com/bing/20190407.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## **Docker容器技术**

### Docker安装与启动

注意：因为docker需要联网操作，所以需要将虚拟机配置成NAT网络模式。Docker必须安装在centos7.0以上

1. 挂载资料中提供好的docker-test镜像   可以通过ip addr命令查看Linux系统ip地址
2. 安装docker  yum install docker   通过docker -v 查看安装的docker版本
3. docker启动与停止 

```
启动docker：systemctl start docker
停止docker：systemctl stop docker
重启docker：systemctl restart docker
查看docker状态：systemctl status docker
开机启动：systemctl enable docker
```

### Docker镜像操作

1. 列出镜像  docker images

2. 配置使用镜像加速器提交拉取速度。修改/daemon.json文件，vi /etc/docker/daemon.json

   ```
   {
   "registry-mirrors": ["https://docker.mirrors.ustc.edu.cn"]
   }

   ```

3. 重启docker    systemctl restart docker

4. 拉取centos镜像   

   ```
   docker pull centos:7
   ```

5. 搜索镜像  搜索网络上镜像

   ```
   //例如搜索tomcat 
   docker search tomcat
   ```

6. 删除镜像   **注意：**包起docker images -q命令的符合是~,是键盘上数字1左侧的符合。

   ```
   1、	docker rmi  IMAGE_ID：删除指定镜像
   2、	docker rmi `docker images -q`：删除所有镜像
   ```

### Docker容器操作

```
-i:运行容器 
-t:启动后进入命令行  
--name=为创建的容器命名  
-d:后台启动  
-v:目录映射关系
-p:端口映射
```

1. 创建交互式容器启动  

   ```
   //						     当前版本   进入后需要执行的解释器
   docker run -it --name=mycentos centos:7 /bin/bash
   执行完该命令后，直接进入容器内部，退出通过exit，容器不能重名，一旦退出，容器也处于停止状态
   ```

2. 创建守护式容器启动  命令：。 执行完该命令后，。。

   ```
   //不进入容器内部
   docker run -di --name=mycentos2 centos:7
   //进入容器的命令：（exit退出时，容器不会停止）
   docker exec -it container_name (或者 container_id)  /bin/bash
   ```

3. 查看容器  

   ```
    //查看正在运行的容器：docker ps
    //查看所有的容器：docker ps -a
   ```

4. 停止与启动容器   

   ```
   //停止容器：docker stop  container_name/ID 
   //启动容器：docker start container_name/id
   ```

5. 删除容器    注意：只能删除停止的容器，正在运行的容器不能被删除

   ```
   删除指定的容器：docker rm $CONTAINER_ID/NAME
   删除所有容器：docker rm `docker ps -a -q`
   ```

### 部署应用

#### mysql部署

1. 拉取mysql镜像 

   ```
    docker pull mysql
   ```

2. 创建mysql容器  （守护式）

```
//									  宿主机端口:容器端口	     容器mysql密码  镜像名
docker run -di --name=pinyougou_mysql -p 33306:3306 -e MYSQL_ROOT_PASSWORD=123456 mysql
```

3. 进入mysql容器

```
docker exec -it pinyougou_mysql /bin/bash
```

4. 在容器中登陆mysql   

   ```
    进入命令：mysql -u root -p   
    退出mysql 命令：quit
   ```

5. 远程登录mysql  **注意：**在navicat链接mysql8以后的版本时，会出现2059的错误，这个错误出现的原因是在mysql8之前的版本中加密规则为mysql_native_password，而在mysql8以后的加密规则为caching_sha2_password。解决此问题有两种方法，一种是更新navicat驱动来解决此问题，一种是将mysql用户登录的加密规则修改为mysql_native_password。本文采用第二种方式。

```
ALTER USER 'root'@'%' IDENTIFIED WITH mysql_native_password BY '123456';#更新一下用户的密码
FLUSH PRIVILEGES;#刷新权限
```

6. 在Navicat中运行品优购建表语句的sql脚本文件，生成品优购数据库、表以及插入测试数据
7. 查看容器ip  **注意：**在宿主机中查看，因为后续需要容器连接容器数据库

```
我们可以通过以下命令查看容器运行的各种数据
docker inspect pinyougou_mysql
也可以直接执行下面的命令直接输出IP地址
docker inspect --format='{{.NetworkSettings.IPAddress}}' pinyougou_mysql
```

#### tomcat部署

1. 拉取tomcat镜像  

   ```
   		    //版本和tomcat中的环境
   docker pull tomcat:7-jre7
   ```

2. 运行tomcat容器 

   ```
   docker run -di --name pinyougou_tomcat -p 9000:8080  tomcat:7-jre7

   //也可以用如下方式进行创建 这样将宿主机的/usr/local/myhtml文件夹映射到容器内的/usr/local/tomcat/webapps目录中，privilege是为了修改一些如/etc/sys里面的文件的时候才需要
   docker run -di --name=pinyougou_tomcat -v /usr/local/myhtml:/usr/local/tomcat/webapps --privileged=true -p 9000:8080 tomcat:7-jre7
   ```

3. 部署web应用   CAS单点登录部署

   1.修改cas系统的配置文件，修改数据库连接的url

   ```
   <bean id="dataSource" class="com.mchange.v2.c3p0.ComboPooledDataSource"
   		p:driverClass="com.mysql.jdbc.Driver"
   		p:jdbcUrl="jdbc:mysql://172.17.0.3:3306/pinyougoudb?characterEncoding=utf8"
   		p:user="root"
   		p:password="123456" />
   ```

   2.将cas文件夹上传至宿主机  通过alt+p进入上传窗口，上传cas文件夹

   ```
   // -r 递归上传
   put -r E:\item\pinyougou306\apache-tomcat-cas\webapps\cas
   ```

   3.从宿主机中，将cas文件夹拷贝到到容器/usr/local/tomcat/webapps目录

   ```
   docker cp cas pinyougou_tomcat:/usr/local/tomcat/webapps
   ```

   4.测试：地址栏输入：http://192.168.25.143:9000/cas/login  宿主机的ip地址

#### Nginx部署

1. 拉取Nginx镜像   

   ```
   docker pull nginx
   ```

2. 创建Nginx容器

```
docker run -di --name=pinyougou_nginx -p 80:80  nginx
```

3. 测试Nginx  访问：http://192.168.25.143

4. 配置反向代理 从容器拷贝配置文件到宿主机

   ```
   //从容器拷贝反向代理文件到本地，修改后再拷贝回容器
   默认挂载html目录: /usr/share/nginx/html
   docker cp pinyougou_nginx:/etc/nginx/nginx.conf nginx.conf
   ```

   配置反向代理

```
upstream tomcat-cas {
	server 172.17.0.6:8080;
}
server {
	listen 80;
	server_name passport.pinyougou.com;
	location / {
		proxy_pass http://tomcat-cas;
		index index.html index.htm;
	}
}
```

将修改后的配置文件拷贝到容器

```
docker cp nginx.conf  pinyougou_nginx:/etc/nginx/nginx.conf
```

重启容器

```
docker restart pinyougou_nginx
```

通过SwitchHosts新增ip地址和域名绑定

```
192.168.184.88 passport.pinyougou.com 
```

重新启动容器

```
docker restart pinyougou_nginx
```

#### Redis部署

1. 拉取Redis镜像  

   ```
   //拉取镜像
   docker pull redis
   ```

2. 创建Redis容器

```
 docker run -di --name=pinyougou_redis -p 6379:6379 redis
```

3. 在你的本地电脑命令提示符下，用window版本redis测试

```
redis-cli -h 192.168.247.135
```

### 备份与迁移

容器保存为镜像

```
              容器名		   保存的镜像名
docker commit pinyougou_nginx mynginx
```

镜像备份

```
			   文件名		容器名
docker  save -o mynginx.tar mynginx
```

镜像恢复与迁移

```
测试删掉 docker rmi myniginx
//恢复加载镜像
docker load -i mynginx.tar
```



修改ip地址

vim /etc/sysconfig/network-scripts/ifcfg-ens33

查看版本

cat /etc/os-release

rpm -qa|grep docker  -查看docker

yum -y remove docker --删除docker

rm -rf /var/lib/docker 