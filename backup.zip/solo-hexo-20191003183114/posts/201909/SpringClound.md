title: SpringClound
date: '2019-09-16 17:09:10'
updated: '2019-09-16 17:09:10'
tags: [Note]
permalink: /articles/2019/09/16/1568624950149.html
---
# SpringCloud快速入门

## 相关概念

SpringCloud

```
springcloud是微服务架构的集大成者，将一系列优秀的组件进行了整合。基于springboot构建，对我们熟悉spring的程序员来说，上手比较容易。

通过一些简单的注解，我们就可以快速的在应用中配置一下常用模块并构建庞大的分布式系统。

SpringCloud的组件相当繁杂，拥有诸多子项目。重点关注Netflix
```

**下面只简单介绍下经常用的5个**

服务发现——Netflix Eureka (Zookeeper)

```
	各个服务启动时，Eureka Client 都会将服务注册到 Eureka Server，并且 Eureka Client 还可以反过来从 Eureka Server 拉取注册表，从而知道其他服务在哪里。
```

客服端负载均衡——Netflix Ribbon 

```
服务间发起请求的时候，基于 Ribbon 做负载均衡，从一个服务的多台机器中选择一台
```

断路器——Netflix Hystrix

```
发起请求通过 Hystrix 的线程池来走的，不同服务走不同线程池，实现不同服务调用的隔离，避免服务雪崩问题

线程隔离：每个请求是独立的线程
熔断机制：生活中保险丝，对请求如果超时直接先返回
```

服务网关——Netflix Zuul

```
前端、移动端要调用后端系统，统一从 Zuul 网关进入，由 Zuul 网关转发请求给对应的服务，zuul的核心是一系列的filters, 其作用可以类比Servlet框架的Filter，或者AOP
```

创建动态代理——Netflix Feign的一个关键机制就是使用了动态代理，并且整合了Hystrix&Ribbon 。

```
基于 Feign 的动态代理机制，根据注解和选择的机器，拼接请求 URL 地址，发起请求。
```



Doubbo分布式架构&微服务概念对比说明

![1561554231676](assets/1561554231676.png)



![1561554259490](assets/1561554259490.png)



两种对比

Doubbo基于RPC，速度快，效率高。早期的webservice，现在热门的dubbo，都是RPC的典型代表，如果公司全部采用Java技术栈，那么使用Dubbo作为微服务架构是一个不错的选择



SpringCloud基于Rest风格Http，缺点是消息封装臃肿，优势是对服务的提供和调用方没有任何技术限定，自由灵活，更符合微服务理念SpringCloud完全支持SpringBoot的开发，用很少的配置就能完成微服务框架的搭建



## 部署实施



![1561555821967](assets/1561555821967.png)



### 一、搭建父工程

（实际开发没有父工程，微服务是独立的）

 		POM坐标设置

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>cn.itcast.demo</groupId>
    <artifactId>cloud-demo</artifactId>
    <version>1.0-SNAPSHOT</version>
    <modules>
        <module>user-service</module>
        <module>consumer-demo</module>
        <module>eureka-server</module>
        <module>eureka-server</module>
        <module>zuul-server</module>
    </modules>
    <packaging>pom</packaging>

    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>2.1.3.RELEASE</version>
        <relativePath/>
    </parent>

    <properties>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
        <project.reporting.outputEncoding>UTF-8</project.reporting.outputEncoding>
        <java.version>1.8</java.version>
        <spring-cloud.version>Greenwich.SR1</spring-cloud.version>
        <mybaitsPlus.version>3.1.1</mybaitsPlus.version>
        <mysql.version>5.1.47</mysql.version>
        <pageHelper.starter.version>1.2.5</pageHelper.starter.version>
    </properties>

    <dependencyManagement>
        <dependencies>
            <!-- springCloud -->
            <dependency>
                <groupId>org.springframework.cloud</groupId>
                <artifactId>spring-cloud-dependencies</artifactId>
                <version>${spring-cloud.version}</version>
                <type>pom</type>
                <scope>import</scope>
            </dependency>
            <!-- mybatisplus -->
            <dependency>
                <groupId>com.baomidou</groupId>
                <artifactId>mybatis-plus-boot-starter</artifactId>
                <version>${mybaitsPlus.version}</version>
            </dependency>
            <!-- mysql驱动 -->
            <dependency>
                <groupId>mysql</groupId>
                <artifactId>mysql-connector-java</artifactId>
                <version>${mysql.version}</version>
            </dependency>
        </dependencies>
    </dependencyManagement>
    <dependencies>
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
    </build>
</project>
```



### 	二、user-service

#### 1.POM配置

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <parent>
        <artifactId>cloud-demo</artifactId>
        <groupId>cn.itcast.demo</groupId>
        <version>1.0-SNAPSHOT</version>
    </parent>
    <modelVersion>4.0.0</modelVersion>

    <artifactId>user-service</artifactId>
    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>mysql</groupId>
            <artifactId>mysql-connector-java</artifactId>
        </dependency>
        <dependency>
            <groupId>com.baomidou</groupId>
            <artifactId>mybatis-plus-boot-starter</artifactId>
        </dependency>
        <!--eureka客户端坐标-->
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
        </dependency>
    </dependencies>

</project>
```

#### 2.yaml配置

```yml
server:
  port: 8081

#datasource
spring:
  datasource:
    driver-class-name: com.mysql.jdbc.Driver
    url: jdbc:mysql:///pinyougoudb
    username: root
    password: root
  application:
    name: user-service
#logger
logging:
  level:
    cn.itcast: debug
#myBatis-plus
mybatis-plus:
  configuration:
    log-impl: org.apache.ibatis.logging.stdout.StdOutImpl  #控制台打印log信息
  mapper-locations: classpath*:mapper/**Mapper.xml		   #mapper映射目录
  type-aliases-package: cn.itcast.user.po				   #pojo目录
eureka:													   #配置eureka
  client:
    service-url:
       defaultZone: http://127.0.0.1:10086/eureka
```

#### 3.启动入口类

```java
package cn.itcast.user;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

//如果选用的注册中心是eureka，推荐@EnableEurekaClient
//其他的注册中心，推荐使用@EnableDiscoveryClient。

@EnableDiscoveryClient
@SpringBootApplication
@MapperScan("cn.itcast.user.mapper")
public class UserApplication {
    public static void main(String[] args) {
        SpringApplication.run(UserApplication.class,args);
    }
}
```

User实体类

```java
package cn.itcast.user.po;

import lombok.Data;
import java.io.Serializable;

@Data
public class User implements Serializable {
    private String uid;

    private String username;

    private String password;

    private String email;

    private String phone;

    private Integer age;

    private String sex;

    private String salt;
    
}
```

UserMapper

```java
package cn.itcast.user.mapper;

import cn.itcast.user.po.TbUser;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface UserMapper extends BaseMapper<TbUser> {

}
```

UserMapper.xml

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN" "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<mapper namespace="cn.itcast.user.mapper.UserMapper">

    <!-- 通用查询映射结果 -->
      <resultMap id="BaseResultMap" type="com.pinyougou.pojo.User">
            <id column="uid" jdbcType="VARCHAR" property="uid" />
            <result column="username" jdbcType="VARCHAR" property="username" />
            <result column="password" jdbcType="VARCHAR" property="password" />
            <result column="email" jdbcType="VARCHAR" property="email" />
            <result column="phone" jdbcType="VARCHAR" property="phone" />
            <result column="age" jdbcType="INTEGER" property="age" />
            <result column="sex" jdbcType="VARCHAR" property="sex" />
            <result column="salt" jdbcType="VARCHAR" property="salt" />
      </resultMap>
</mapper>
```

UserService.java

```java
package cn.itcast.user.service;

import cn.itcast.user.po.TbUser;
import com.baomidou.mybatisplus.extension.service.IService;

public interface UserService extends IService<TbUser> {

}
```

UserServiceImpl

```java
package cn.itcast.user.service.impl;

import cn.itcast.user.mapper.UserMapper;
import cn.itcast.user.po.TbUser;
import cn.itcast.user.po.User;
import cn.itcast.user.service.UserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, TbUser> implements UserService {

}
```

UserController

```java
package cn.itcast.user.controller;

import cn.itcast.user.po.User;
import cn.itcast.user.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("{id}")
    public User findOne(@PathVariable Long id){
        return userService.getById(id);
    }

    @PostMapping
    public Map add(@RequestBody User user){
        Map map = new HashMap<>();
        try {
            userService.save(user);
            map.put("true", "新增成功");
            return map;
        } catch (Exception e) {
            e.printStackTrace();
            map.put("false", "新增失败");
            return map;
        }
    }

    @GetMapping
    public List<User> findAll(){
        return userService.list();
    }
}
```



### 	三、user-consumer

#### 1.POM配置

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <parent>
        <artifactId>cloud-demo</artifactId>
        <groupId>cn.itcast.demo</groupId>
        <version>1.0-SNAPSHOT</version>
    </parent>
    <modelVersion>4.0.0</modelVersion>

    <artifactId>consumer-demo</artifactId>

    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-openfeign</artifactId>
        </dependency>
    </dependencies>

</project>
```

#### 2.yaml配置

```yml
server:
  port: 8080
spring:
  application:
    name: consumer-demo
eureka:
  client:
    service-url:
      defaultZone: http://127.0.0.1:10086/eureka
feign:
  hystrix:
    enabled: true # 开启Feign的熔断功能
```

#### 3.启动入口类

```java
package cn.itcast.consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;


@EnableDiscoveryClient
@EnableFeignClients
@SpringBootApplication
public class ConsumerApplication {

    public static void main(String[] args) {
        SpringApplication.run(ConsumerApplication.class,args);
    }

}
```

POJO

```JAVA
package cn.itcast.consumer.pojo;

import lombok.Data;

import java.io.Serializable;

@Data
public class User implements Serializable {

    private Long uid;

    private String username;

    private String password;

    private String email;

    private String phone;

    private Integer age;

    private String sex;

    private String salt;

}
```

UserServiceClient

```java
package cn.itcast.consumer.client;

import cn.itcast.consumer.pojo.User;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;
import java.util.Map;

@FeignClient(value = "user-service",fallback = UserClientFallBack.class)
public interface UserServiceClient  {

    @GetMapping("/user/{id}")
    User findOne(@PathVariable(value = "id") Long id);

    @PostMapping("/user")
    Map add(User user);

    @GetMapping("/user")
    List<User> findAll();
}

```

UserClientFallBack

```java
package cn.itcast.consumer.client;

import cn.itcast.consumer.pojo.User;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
public class UserClientFallBack implements UserServiceClient {

    @Override
    public User findOne(Long id) {
        return null;
    }

    @Override
    public Map add(User user) {
        return null;
    }

    @Override
    public List<User> findAll() {
        return null;
    }
}
```

ConsumerController

```java
package cn.itcast.consumer.controller;

import cn.itcast.consumer.feignClient.UserServiceClient;
import cn.itcast.consumer.po.TbUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/consume")
public class ConsumerController {

    @Autowired
    private UserServiceClient userServiceClient;

    @GetMapping("{userId}")
    public TbUser findUserByIdFeign(@PathVariable Long userId) {
        //服务id名称
        TbUser myUser = userServiceClient.getMyUser(userId);
        return myUser;
    }
}
```



### 	四、eureka-server

#### 1.POM配置

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <parent>
        <artifactId>cloud-demo</artifactId>
        <groupId>cn.itcast.demo</groupId>
        <version>1.0-SNAPSHOT</version>
    </parent>
    <modelVersion>4.0.0</modelVersion>

    <artifactId>eureka-server</artifactId>

    <dependencies>
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-netflix-eureka-server</artifactId>
        </dependency>
    </dependencies>

</project>
```

#### 2.yaml配置

```yml
server:
  port: 10086
spring:
  application:
    name: eureka-server		  #serviceId  微服务的标识
eureka:
  client:
    service-url:
      defaultZone: http://127.0.0.1:10086/eureka		      	#eureka 的注册地址
    fetch-registry: false									    #单台Eureka不拉取服务
    register-with-eureka: false								    #单台Eureka不注册自己
```

#### 3.启动入口类

```java
package cn.itcast;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@EnableEurekaServer
@SpringBootApplication
public class EurekaServer {
    public static void main(String[] args) {
        SpringApplication.run(EurekaServer.class,args);
    }
}
```

### 五、zuul-server

![1561556111923](assets/1561556111923.png)

#### 1.POM配置

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <parent>
        <artifactId>cloud-demo</artifactId>
        <groupId>cn.itcast.demo</groupId>
        <version>1.0-SNAPSHOT</version>
    </parent>
    <modelVersion>4.0.0</modelVersion>

    <artifactId>zuul-server</artifactId>

    <dependencies>
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-netflix-zuul</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.cloud</groupId>
            <artifactId>spring-cloud-starter-netflix-eureka-client</artifactId>
        </dependency>
    </dependencies>
</project>
```

#### 2.yaml配置

```yml
server:
  port: 10010
spring:
  application:
    name: api-gateway
zuul:
  prefix: /api # 添加路由前缀
  routes:
    user-service: /user-service/**  #映射路径
    consumer-demo: /consumer-demo/**
    
eureka:
  client:
    service-url:
      defaultZone: http://127.0.0.1:10086/eureka
```

#### 3.启动入口类

```java
package cn.itcast;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;

@EnableZuulProxy  //当Zuul与Eureka、Ribbon等组件配合使用时,使用该注解
@EnableDiscoveryClient  
@SpringBootApplication
public class ZuulServer {
    public static void main(String[] args) {
        SpringApplication.run(ZuulServer.class,args);
    }
}
```

zuul访问测试

```
http://localhost:10010/api/consumer-demo/consumer
http://localhost:10010/api/user-service/user
```

#### 4.自定义过滤器

```java
package cn.itcast;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;
import org.apache.commons.lang.StringUtils;
import org.springframework.cloud.netflix.zuul.filters.support.FilterConstants;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;

@Component
public class LoginFilter extends ZuulFilter {

    @Override
    public String filterType() {
        return FilterConstants.PRE_TYPE;
    }

    @Override
    public int filterOrder() {
        return FilterConstants.PRE_DECORATION_FILTER_ORDER - 1;
    }

    @Override
    public boolean shouldFilter() {
        return true;
    }

    @Override
    public Object run() throws ZuulException {
        // 获取请求上下文
        RequestContext ctx = RequestContext.getCurrentContext();
        // 获取request对象
        HttpServletRequest request = ctx.getRequest();
        // 获取请求参数
        String token = request.getParameter("token");
        // 判断是否存在
        if(StringUtils.isBlank(token)){
            // 不存在，未登录，拦截
            ctx.setSendZuulResponse(false);
            // 设置返回状态码
            ctx.setResponseStatusCode(HttpStatus.UNAUTHORIZED.value());
        }
        return null;
    }
}
```

zuul访问测试

```
http://localhost:10010/api/consumer-demo/consumer?token=itcast
```