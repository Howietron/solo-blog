title: java的一些常见异常
date: '2019-07-10 17:30:23'
updated: '2019-07-10 17:40:26'
tags: [常见问题]
permalink: /articles/2019/07/10/1562751023589.html
---
![javaimg.png](https://img.hacpai.com/file/2019/07/javaimg-65d463e7.png)

# java的一些常见异常

异常类分两大类型：

​	Error类代表了编译和系统的错误，不允许捕获；

​	Exception类代表了标准Java库方法所激发的异常。

Exception类还包含运行异常类Runtime_Exception和非运行异常类Non_RuntimeException这两个直接的子类。

​       运行异常类对应于编译错误，它是指Java程序在运行时产生的由解释器引发的各种异常。运行异常可能出现在任何地方，且出现频率很高，因此为了避免巨大的系统资源开销，编译器不对异常进行检查。所以Java语言中的运行异常不一定被捕获。出现运行错误往往表示代码有错误，如：算数异常（如被0除）、下标异常（如数组越界）等。

​       非运行异常时Non_RuntimeException类及其子类的实例，又称为可检测异常。Java编译器利用分析方法或构造方法中可能产生的结果来检测Java程序中是否含有检测异常的处理程序，对于每个可能的可检测异常，方法或构造方法的throws子句必须列出该异常对应的类。在Java的标准包java.lang  java.util  和 java.net  中定义的异常都是非运行异常。



## 几种常见Exception和Error

### 1.java.lang.ClassNotFoundException_指定的类不存在

　　这个异常是很多原本在JB等开发环境中开发的程序员，把JB下的程序包放在WTk下编译经常出现的问题，异常的解释是 “指定的类不存在 “，这里主要考

虑一下类的名称和路径是否正确即可，如果是在JB下做的程序包，一般都是默认加上Package的，所以转到WTK下后要注意把Package的路径加上。

### 2.java.lang.ArithmeticException_数学运算异常

　　这个异常的解释是 “数学运算异常 “，比如程序中出现了除以零这样的运算就会出这样的异常，对这种异常，大家就要好好检查一下自己程序中涉及到数

学运算的地方，公式是不是有不妥了。

### 3.java.lang.ArrayIndexOutOfBoundsException_数组下标越界

　　这个异常相信很多朋友也经常遇到过，异常的解释是 “数组下标越界 “，现在程序中大多都有对数组的操作，因此在调用数组的时候一定要认真检查，看

自己调用的下标是不是超出了数组的范围，一般来说，显示（即直接用常数当下标）调用不太容易出这样的错，但隐式（即用变量表示下标）调用就经常出错

了，还有一种情况，是程序中定义的数组的长度是通过某些特定方法决定的，不是事先声明的，这个时候，最好先查看一下数组的length，以免出现这个异常

。

### 4.java.lang.ArrayStoreException_数组存储异常

 当试图将类型不兼容类型的对象存入一个Object[]数组时将引发异常

```java
      Object[] obj = new String[3];

      obj[0] = new Integer(0);
```

### 5.java.lang.IllegalArgumentException_方法的参数错误

　　这个异常的解释是 “方法的参数错误 “，很多J2ME的类库中的方法在一些情况下都会引发这样的错误，比如音量调节方法中的音量参数如果写成负数就会

出现这个异常，再比如g.setColor(int red,int green,int blue)这个方法中的三个值，如果有超过２５５的也会出现这个异常，因此一旦发现这个异

常，我们要做的，就是赶紧去检查一下方法调用中的参数传递是不是出现了错误。 

### 6.java.lang.IllegalAccessException_没有访问权限

　　这个异常的解释是 “没有访问权限 “，当应用程序要调用一个类，但当前的方法即没有对该类的访问权限便会出现这个异常。对程序中用了Package的情

况下要注意这个异常。

### 7.java.lang.ClassCastException_数据类型转换异常

当试图将对某个对象强制执行向下转型，但该对象又不可转换又不可转换为其子类的实例时将引发该异常，如下列代码。

```java
     Object obj = new Integer(0);

     String str = obj;
```

### 8.java.lang.FileNotFoundException_文件未找到异常

当程序试图打开一个不存在的文件进行读写时将会引发该异常。该异常由FileInputStream,FileOutputStream,RandomAccessFile的构造器声明抛出

即使被操作的文件存在，但是由于某些原因不可访问，比如打开一个只读文件进行写入，这些构造方法仍然会引发异常



### 9.java.lang.NoClassDefFoundException_未找到类定义错误

当Java虚拟机或者类装载器试图实例化某个类，而找不到该类的定义时抛出该错误。

### 10.java.lang.OutOfMemoryException_内存不足错误

当可用内存不足以让Java虚拟机分配给一个对象时抛出该错误。

### 11.java.lang.IncompatibleClassChangeError_不兼容的类变化错误

当正在执行的方法所依赖的类定义发生了不兼容的改变时，抛出该异常。一般在修改了应用中的某些类的声明定义而没有对整个应用重

新编译而直接运行的情况下，容易引发该错误。

### 12.java.lang.InstantiationError_实例化错误

当一个应用试图通过Java的new操作符构造一个抽象类或者接口时抛出该异常.

### 13.java.lang.LinkageError_链接错误

该错误及其所有子类指示某个类依赖于另外一些类，在该类编译之后，被依赖的类改变了其类定义而没有重新编译所有的类，进而引发错误的情况

。

### 14.java.lang.StackOverflowError_堆栈溢出错误

当一个应用递归调用的层次太深而导致堆栈溢出时抛出该错误。